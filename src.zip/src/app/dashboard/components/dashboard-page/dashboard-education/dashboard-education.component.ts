import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-education',
  templateUrl: './dashboard-education.component.html',
  styleUrls: ['./dashboard-education.component.css'],
})
export class DashboardEducationComponent implements OnInit {
  @Input('education') education: any[] = [];
  constructor() {}

  ngOnInit(): void {}
}
