import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-education-row',
  templateUrl: './dashboard-education-row.component.html',
  styleUrls: ['./dashboard-education-row.component.css'],
})
export class DashboardEducationRowComponent implements OnInit {
  @Input() e: any = {};
  constructor() {}

  ngOnInit(): void {}
}
