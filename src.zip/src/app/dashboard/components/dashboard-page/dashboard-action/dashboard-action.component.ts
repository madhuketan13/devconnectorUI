import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-action',
  templateUrl: './dashboard-action.component.html',
  styleUrls: ['./dashboard-action.component.css']
})
export class DashboardActionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
