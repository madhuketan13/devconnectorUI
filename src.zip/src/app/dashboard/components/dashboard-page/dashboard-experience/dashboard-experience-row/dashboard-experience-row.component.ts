import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-experience-row',
  templateUrl: './dashboard-experience-row.component.html',
  styleUrls: ['./dashboard-experience-row.component.css'],
})
export class DashboardExperienceRowComponent implements OnInit {
  @Input() e: any = {};
  constructor() {}

  ngOnInit(): void {}
}
