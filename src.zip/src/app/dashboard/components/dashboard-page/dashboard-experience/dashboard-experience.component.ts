import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-experience',
  templateUrl: './dashboard-experience.component.html',
  styleUrls: ['./dashboard-experience.component.css'],
})
export class DashboardExperienceComponent implements OnInit {
  @Input() experience: any[] = [];
  constructor() {}

  ngOnInit(): void {
    // this.experience.forEach((ele) => console.log(ele));
  }
}
