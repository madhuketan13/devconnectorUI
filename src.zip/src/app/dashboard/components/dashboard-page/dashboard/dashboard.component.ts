import { Component, OnInit } from '@angular/core';
import { ProfileService } from 'src/app/profile/services/profile.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  constructor(private profileService: ProfileService) {}
  flag: boolean = false;

  userDetails: any = {};
  profile: any = {};
  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails') || '');

    console.log(this.userDetails.id);

    this.profileService.getProfile(this.userDetails.id).subscribe(
      (res) => {
        console.log(res);
        localStorage.setItem("profileDetails", JSON.stringify(res));
        this.profile = res;
      },
      (err) => {
        console.log(err.status);
        if (err.status == 404) {
          this.flag = true;
        }
      }
    );
  }
}
