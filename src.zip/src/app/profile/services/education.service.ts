import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IEducation } from '../models/ieducation';
import { Observable } from 'rxjs';

const headerData = {
  headers: { 'Content-Type': 'application/json' },
};

@Injectable({
  providedIn: 'root',
})
export class EducationService {
  constructor(private httpClient: HttpClient) {}

  endPoint: string = '/api/education';
  
  addEducation(education: IEducation): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/create',
      education,
      headerData
    );
  }
}
