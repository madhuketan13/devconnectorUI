import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IProfile } from '../models/iprofile';

const headerData = {
  headers: { 'Content-Type': 'application/json' },
};

@Injectable({
  providedIn: 'root',
})
export class ProfileService {
  constructor(private httpClient: HttpClient) {}
  endPoint: string = '/api/profile';

  getProfile(userId: number): Observable<any> {
    return this.httpClient.get(this.endPoint + '/user/' + userId);
  }

  createProfile(profile: IProfile): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/create',
      profile,
      headerData
    );
  }
}
