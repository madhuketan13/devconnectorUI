export interface IExperience {
  jobTitle: string;
  company: string;
  location: string;
  fromDate: Date | null;
  currentJob: boolean;
  toDate: Date | null;
  jobDescription: string;
  profileId: string;
}
