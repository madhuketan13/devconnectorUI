export interface IEducation {
  schoolName: string;
  degreeName: string;
  fieldOfStudy: string;
  fromDate: Date | null;
  currentSchool: boolean;
  toDate: Date | null;
  programDescription: string;
  profileId: string;
}
