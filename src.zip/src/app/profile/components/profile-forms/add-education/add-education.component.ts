import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IEducation } from 'src/app/profile/models/ieducation';
import { EducationService } from 'src/app/profile/services/education.service';

@Component({
  selector: 'app-add-education',
  templateUrl: './add-education.component.html',
  styleUrls: ['./add-education.component.css'],
})
export class AddEducationComponent implements OnInit {
  education: IEducation = {
    schoolName: '',
    degreeName: '',
    fieldOfStudy: '',
    fromDate: null,
    currentSchool: false,
    toDate: null,
    programDescription: '',
    profileId: '',
  };
  constructor(private educationService: EducationService, private router: Router) {}

  ngOnInit(): void {}

  onAddEducation() {
    this.education.profileId = JSON.parse(localStorage.getItem("profileDetails") || '').profileId
    this.educationService.addEducation(this.education).subscribe(
      (res) => {
        console.log(res);
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
