import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IExperience } from 'src/app/profile/models/iexperience';
import { ExperienceService } from 'src/app/profile/services/experience.service';

@Component({
  selector: 'app-add-experience',
  templateUrl: './add-experience.component.html',
  styleUrls: ['./add-experience.component.css'],
})
export class AddExperienceComponent implements OnInit {
  experience: IExperience = {
    jobTitle: '',
    company: '',
    location: '',
    fromDate: null,
    currentJob: false,
    toDate: null,
    jobDescription: '',
    profileId: ''
  };
  constructor(private experienceService: ExperienceService, private router: Router) {}

  ngOnInit(): void {}

  onAddExperience() {
    console.log(this.experience);
    this.experience.profileId = JSON.parse(localStorage.getItem("profileDetails") || '').profileId
    this.experienceService.addExperience(this.experience).subscribe(
      (res) => {
        console.log(JSON.stringify(res));
        this.router.navigate(['/dashboard'])

      },
      (err) => {
        console.log(err);
      }
    );
  }
}
