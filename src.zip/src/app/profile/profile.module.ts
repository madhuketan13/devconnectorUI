import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { CreateProfileComponent } from './components/profile-forms/create-profile/create-profile.component';
import { AddEducationComponent } from './components/profile-forms/add-education/add-education.component';
import { AddExperienceComponent } from './components/profile-forms/add-experience/add-experience.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ExperienceService } from './services/experience.service';
import { EducationService } from './services/education.service';
import { ProfileService } from './services/profile.service';
import { httpInterceptors } from '../shared/interceptors';

@NgModule({
  declarations: [
    CreateProfileComponent,
    AddEducationComponent,
    AddExperienceComponent,
  ],
  imports: [CommonModule, FormsModule, HttpClientModule, ProfileRoutingModule],
  providers: [ExperienceService, httpInterceptors ,EducationService, ProfileService],
})
export class ProfileModule {}
